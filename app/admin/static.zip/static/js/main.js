$(document).ready(function () {

    // index page
    new WOW().init();

    $('.search-icon').click(function () {
        $('#search-window').css('height','100vh');
    });

    $('#search-window .fa-times').click(function () {
        $('#search-window').css('height','0vh');
    });


    $('.toggler-bars .fa-bars').click(function () {
        $('#menu-toggle').css('width','85%');

    });

    $('.toggler-times').click(function () {
        $('#menu-toggle').css('width','0%');
    });

    //Go Top Button
    goTop();

    //Go Top Button
    $(window).on('scroll', function () {
        goTop();
    });

    //Go Top Button
    function goTop() {
        if ($(window).scrollTop() > 1600 ) {
            $(".special-button").slideDown(700)
        }
        if ($(window).scrollTop() < 1200 ) {
            $(".special-button").slideUp(700)
        }
    }

    // Navbar Sticky Button
    navbarSticky();

    // Navbar Sticky Button
    $(window).on('scroll', function () {
        navbarSticky();
    });

    // Navbar Sticky Button
    function navbarSticky() {
        if ($(window).scrollTop() > 500) {
            $(".header-content").addClass("fixed-top");
        }
        if ($(window).scrollTop() < 5) {
            $(".header-content").removeClass("fixed-top");
        }
    }

    // navbar hide menu on scroll
    var prevScrollpos = window.pageYOffset;
    window.onscroll = function () {
        var currentScrollPos = window.pageYOffset;
        if (prevScrollpos > currentScrollPos) {
            document.getElementById("header-content").style.top = "0";
        } else {
            document.getElementById("header-content").style.top = "-100px";
        }
        prevScrollpos = currentScrollPos;
    }


    // Navbar Sticky Button
    digitalCoinNews();

    // Navbar Sticky Button
    $(window).on('scroll', function () {
        digitalCoinNews();
    });

    // Navbar Sticky Button
    function digitalCoinNews() {
        if ($(window).scrollTop() > 1500) {
            $(".digital-coin").slideDown(400);
        }
        if ($(window).scrollTop() < 1000) {
            $(".digital-coin").slideUp(400);
        }
    }


    $('.owl-carousel').owlCarousel({
        rtl: true,
        autoplay: true,
        autoplayTimeout: 2500,
        autoplayHoverPause: true,
        loop: true,
        margin: 10,
        nav: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 2
            },
            1000: {
                items: 4
            }
        }
    });





    // about us page 
    $('.fixed-menu-bar').click(function () {
        $('.fixed-menu-bar-open').toggle(300);
    });

    $('[data-toggle="popover"]').popover();
    $('[data-toggle="tooltip"]').tooltip();

    // pagination active class set
    const currentlocation = location.href;
    const items = document.querySelectorAll('#pagination a');
    const menulength = items.length
    for (let i = 0; i<menulength; i++){
        if (items[i].href === currentlocation){
            items[i].className = "active"
        }
    }

});


particlesJS("particles-js", {
  "particles": {
    "number": {
      "value": 80,
      "density": {
        "enable": true,
        "value_area": 800
      }
    },
    "color": {
      "value": "#000"
    },
    "shape": {
      "type": "circle",
      "stroke": {
        "width": 0,
        "color": "#000000"
      },
      "polygon": {
        "nb_sides": 5
      },
      "image": {
        "src": "img/github.svg",
        "width": 100,
        "height": 100
      }
    },
    "opacity": {
      "value": 0.5,
      "random": false,
      "anim": {
        "enable": false,
        "speed": 1,
        "opacity_min": 0.1,
        "sync": false
      }
    },
    "size": {
      "value": 3,
      "random": true,
      "anim": {
        "enable": false,
        "speed": 40,
        "size_min": 0.1,
        "sync": false
      }
    },
    "line_linked": {
      "enable": true,
      "distance": 120,
      "color": "#000",
      "opacity": 0.4,
      "width": 1
    },
    "move": {
      "enable": true,
      "speed": 3,
      "direction": "none",
      "random": false,
      "straight": false,
      "out_mode": "out",
      "bounce": false,
      "attract": {
        "enable": false,
        "rotateX": 600,
        "rotateY": 1200
      }
    }
  },
  "interactivity": {
    "detect_on": "canvas",
    "events": {
      "onhover": {
        "enable": true,
        "mode": "grab"
      },
      "onclick": {
        "enable": true,
        "mode": "push"
      },
      "resize": true
    },
    "modes": {
      "grab": {
        "distance": 140,
        "line_linked": {
          "opacity": 1
        }
      },
      "bubble": {
        "distance": 400,
        "size": 40,
        "duration": 2,
        "opacity": 8,
        "speed": 3
      },
      "repulse": {
        "distance": 200,
        "duration": 0.4
      },
      "push": {
        "particles_nb": 2
      },
      "remove": {
        "particles_nb": 2
      }
    }
  },
  "retina_detect": true
});


/* ---- stats.js config ---- */

var count_particles, stats, update;
stats = new Stats;
stats.setMode(0);
stats.domElement.style.position = 'absolute';
stats.domElement.style.left = '0px';
stats.domElement.style.top = '0px';
document.body.appendChild(stats.domElement);
count_particles = document.querySelector('.js-count-particles');
update = function() {
  stats.begin();
  stats.end();
  if (window.pJSDom[0].pJS.particles && window.pJSDom[0].pJS.particles.array) {
    count_particles.innerText = window.pJSDom[0].pJS.particles.array.length;
  }
  requestAnimationFrame(update);
};
requestAnimationFrame(update);